import TrendForgeApp from '@/components/TrendForgeApp';
export default function Home() {
  return <TrendForgeApp />;
}
